/* ===== LANGUAGE TOGGLE ===== */
let currentLang = localStorage.getItem('fb_lang') || 'en';

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem('fb_lang', lang);
  document.body.className = 'lang-' + lang;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });

  document.querySelectorAll('.en-only').forEach(el => {
    el.style.display = lang === 'en' ? '' : 'none';
  });
  document.querySelectorAll('.ar-only').forEach(el => {
    el.style.display = lang === 'ar' ? '' : 'none';
  });

  // Update menu tabs
  switchMenuTab(currentMenuTab);
}

document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => setLang(btn.dataset.lang));
});

// Initialize
setLang(currentLang);

/* ===== STICKY NAV ===== */
const nav = document.querySelector('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 60);
});

/* ===== SMOOTH SCROLL NAV LINKS ===== */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

/* ===== AOS-LIKE SCROLL ANIMATIONS ===== */
const aosObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const delay = entry.target.dataset.aosDelay || 0;
      setTimeout(() => {
        entry.target.classList.add('aos-animate');
      }, parseInt(delay));
      aosObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

document.querySelectorAll('[data-aos]').forEach(el => {
  aosObserver.observe(el);
});

/* ===== MENU TABS ===== */
let currentMenuTab = 0;

function switchMenuTab(index) {
  currentMenuTab = index;
  document.querySelectorAll('.menu-tab').forEach((tab, i) => {
    tab.classList.toggle('active', i === index);
  });
  document.querySelectorAll('.menu-panel').forEach((panel, i) => {
    panel.classList.toggle('active', i === index);
  });
}

document.querySelectorAll('.menu-tab').forEach((tab, i) => {
  tab.addEventListener('click', () => switchMenuTab(i));
});

// Start on first tab
switchMenuTab(0);

/* ===== FLOATING PARTICLES ===== */
function createParticles() {
  const container = document.querySelector('.particles');
  if (!container) return;
  const count = 18;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = Math.random() * 8 + 4;
    p.style.cssText = `
      left: ${Math.random() * 100}%;
      width: ${size}px;
      height: ${size}px;
      --duration: ${Math.random() * 8 + 6}s;
      --delay: ${Math.random() * 8}s;
      opacity: ${Math.random() * 0.5 + 0.2};
      background: rgba(245, 158, 11, ${Math.random() * 0.4 + 0.1});
      border-radius: ${Math.random() > 0.5 ? '50%' : '3px'};
    `;
    container.appendChild(p);
  }
}
createParticles();

/* ===== HERO PARALLAX ===== */
const heroBg = document.querySelector('.hero-bg');
window.addEventListener('scroll', () => {
  if (heroBg && window.scrollY < window.innerHeight) {
    heroBg.style.transform = `scale(1.1) translateY(${window.scrollY * 0.3}px)`;
  }
}, { passive: true });

/* ===== GALLERY LIGHTBOX ===== */
const lightbox = document.createElement('div');
lightbox.id = 'lightbox';
lightbox.innerHTML = `
  <div id="lightbox-backdrop" style="
    position: fixed; inset: 0; background: rgba(0,0,0,0.9); z-index: 10000;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; opacity: 0; transition: opacity 0.3s ease;
  ">
    <img id="lightbox-img" src="" style="
      max-width: 90vw; max-height: 90vh; border-radius: 16px;
      box-shadow: 0 30px 80px rgba(0,0,0,0.5);
      transform: scale(0.9); transition: transform 0.3s ease;
    ">
    <button style="
      position: absolute; top: 24px; right: 24px; background: rgba(255,255,255,0.15);
      border: none; color: white; width: 48px; height: 48px; border-radius: 50%;
      font-size: 1.5rem; cursor: pointer; backdrop-filter: blur(10px);
    ">×</button>
  </div>
`;
document.body.appendChild(lightbox);

const lb = document.getElementById('lightbox-backdrop');
const lbImg = document.getElementById('lightbox-img');

document.querySelectorAll('.gallery-item').forEach(item => {
  item.addEventListener('click', () => {
    const src = item.querySelector('img').src;
    lbImg.src = src;
    lb.style.display = 'flex';
    requestAnimationFrame(() => {
      lb.style.opacity = '1';
      lbImg.style.transform = 'scale(1)';
    });
  });
});

lb.addEventListener('click', () => {
  lb.style.opacity = '0';
  lbImg.style.transform = 'scale(0.9)';
  setTimeout(() => { lb.style.display = 'none'; }, 300);
});

/* ===== COUNTER ANIMATION ===== */
function animateCounters() {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseInt(el.dataset.count);
    let current = 0;
    const step = target / 60;
    const timer = setInterval(() => {
      current += step;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      el.textContent = Math.floor(current) + (el.dataset.suffix || '');
    }, 16);
  });
}

const statsSection = document.querySelector('.about-image-badge');
if (statsSection) {
  const statsObserver = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      animateCounters();
      statsObserver.disconnect();
    }
  }, { threshold: 0.5 });
  statsObserver.observe(statsSection);
}
