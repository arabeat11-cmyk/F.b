from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import json
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'fb-coffee-secret-saltjordan-2024')

CONTENT_FILE = os.path.join(os.path.dirname(__file__), 'content.json')


def load_content():
    with open(CONTENT_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_content(data):
    with open(CONTENT_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


@app.route('/')
def index():
    content = load_content()
    return render_template('index.html', content=content)


@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST' and 'password' in request.form:
        content = load_content()
        if request.form['password'] == content['meta']['admin_password']:
            session['admin'] = True
            return redirect(url_for('admin'))
        return render_template('admin_login.html', error=True)

    if not session.get('admin'):
        return render_template('admin_login.html', error=False)

    content = load_content()
    return render_template('admin.html', content=content)


@app.route('/admin/save', methods=['POST'])
def admin_save():
    if not session.get('admin'):
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    data = request.json
    try:
        save_content(data)
        return jsonify({'success': True, 'message': 'Content saved successfully!'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect(url_for('index'))


@app.route('/content.json')
def get_content():
    content = load_content()
    public = {k: v for k, v in content.items() if k != 'meta'}
    return jsonify(public)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    app.run(host='0.0.0.0', port=port, debug=True, use_reloader=False)
